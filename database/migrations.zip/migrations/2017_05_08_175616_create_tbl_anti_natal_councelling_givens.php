<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblAntiNatalCouncellingGivens extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_anti_natal_councelling_givens', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('client_id');
            $table->foreign('client_id')->references('id')->on('tbl_anti_natal_registers');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->uuid('description_id');
            $table->foreign('description_id')->references('id')->on('tbl_anti_natal_councelling_areas');
            $table->string('status',12);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_anti_natal_councelling_givens');
    }
}
