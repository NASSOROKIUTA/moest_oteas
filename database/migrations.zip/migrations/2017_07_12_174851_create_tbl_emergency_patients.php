<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblEmergencyPatients extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_emergency_patients', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('visiting_id')->nullable();
            $table->foreign('visiting_id')->references('id')->on('tbl_accounts_numbers');
            $table->uuid('emergency_type_id')->nullable();
            $table->foreign('emergency_type_id')->references('id')->on('tbl_emergency_types');
            $table->uuid('registered_by')->nullable();
            $table->foreign('registered_by')->references('id')->on('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_emergency_patients');

    }
}
