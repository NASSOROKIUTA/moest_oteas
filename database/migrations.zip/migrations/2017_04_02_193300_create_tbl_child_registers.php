<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblChildRegisters extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_child_registers', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->integer('residence_id',false,true)->length(11)->unsigned()->nullable;
            $table->foreign('residence_id')->references('id')->on('tbl_residences');
            $table->string('client_name');
            $table->date('dob');
            $table->string('gender',7);
            $table->float('weight');
            $table->string('midwife');
            $table->string('delivery_place');
            $table->string('mother_name');
            $table->string('father_name')->nullable();
            $table->string('serial_no',10);
            $table->string('mobile_number',20)->nullable();
            $table->string('year',4);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_child_registers');
    }
}
