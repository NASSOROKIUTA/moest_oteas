<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblOrders extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

		Schema::create('tbl_orders', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->string('priority',10)->nullable();
            $table->string('clinical_note',100);
            $table->uuid('receiver_id')->nullable();
            $table->foreign('receiver_id')->references('id')->on('users');
            $table->uuid('processor_id')->nullable();
            $table->foreign('processor_id')->references('id')->on('users');
            $table->time('time_received')->nullable();
            $table->uuid('test_id')->nullable();
            $table->foreign('test_id')->references('id')->on('tbl_items');
			$table->uuid('order_id')->nullable();
            $table->foreign('order_id')->references('id')->on('tbl_requests');
			$table->string('sample_no',50)->nullable();
			$table->string('sample_types',100)->nullable();
			$table->boolean('order_control')->nullable();
			$table->string('order_cancel_reason',200)->nullable();
			$table->boolean('order_status')->nullable();
			$table->uuid('order_validator_id')->nullable();
            $table->foreign('order_validator_id')->references('id')->on('users');
			$table->boolean('result_control')->nullable();
			$table->boolean('eraser')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
		Schema::dropIfExists('tbl_orders');
    }
}
