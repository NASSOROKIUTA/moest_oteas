<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblClientViolences extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_client_violences', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->integer('violence_type_id',false,true)->length(11)->unsigned();
            $table->foreign('violence_type_id')->references('id')->on('tbl_violence_types');
            $table->integer('sub_violence_id',false,true)->length(11)->unsigned();
            $table->foreign('sub_violence_id')->references('id')->on('tbl_violence_sub_categories');
            $table->integer('violence_category_id',false,true)->length(11)->unsigned();
            $table->foreign('violence_category_id')->references('id')->on('tbl_violence_categories');
            $table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->dateTime('event_date')->nallable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_client_violences');
    }
}
