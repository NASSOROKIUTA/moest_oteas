<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateReviewOfSystems extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_review_of_systems',function(Blueprint $table){
            $table->uuid('id');
            $table->primary('id');
            $table->string('status',50)->nullable();
            $table->uuid('review_system_id')->nullable();
            $table->foreign('review_system_id')->references('id')->on('tbl_review_systems');
            $table->uuid('system_id')->nullable();
            $table->foreign('system_id')->references('id')->on('tbl_body_systems');
            $table->string('review_summary')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_review_of_systems');
    }
}
