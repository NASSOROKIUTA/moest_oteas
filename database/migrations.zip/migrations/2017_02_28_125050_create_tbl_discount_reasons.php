<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblDiscountReasons extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_discount_reasons', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
			
			$table->string('discount_reason',200);
			
			$table->uuid('receipt_number')->nullable();
			
			
            $table->foreign('receipt_number')->references('invoice_id')->on('tbl_invoice_lines');
			
			$table->uuid('patient_id')->nullable();
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
			
			$table->uuid('facility_id')->nullable();
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_discount_reasons');
    }
}
