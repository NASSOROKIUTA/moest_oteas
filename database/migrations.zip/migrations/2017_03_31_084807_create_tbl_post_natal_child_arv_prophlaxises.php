<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblPostNatalChildArvProphlaxises extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_post_natal_child_arv_prophlaxises', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->uuid('arv_id');
            $table->foreign('arv_id')->references('id')->on('tbl_items');
            $table->string('time',5);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_post_natal_child_arv_prophlaxises');
    }
}
