<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBirthChildHistories extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_child_birth_histories',function (Blueprint $table){
            $table->uuid('id');
            $table->primary('id');
            $table->string('antenatal',100);
            $table->string('natal',100);
            $table->string('post_natal',100);
            $table->string('nutrition',100);
            $table->string('growth',100);
            $table->string('development',100);
            $table->uuid('birth_history_id');
            $table->foreign('birth_history_id')->references('id')->on('tbl_birth_histories');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_child_birth_historys');
    }
}
