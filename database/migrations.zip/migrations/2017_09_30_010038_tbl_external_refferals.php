<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TblExternalRefferals extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_refferal_externals', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->string('patient_condition',200)->nullable();
            $table->string('preparation_needed',200)->nullable();
			$table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');        
			$table->uuid('escorting_staff');
            $table->foreign('escorting_staff')->references('id')->on('users');        
			$table->integer('status',false,true)->length(1);
			$table->uuid('sender_facility_id');
            $table->foreign('sender_facility_id')->references('id')->on('tbl_facilities');  
			$table->uuid('reffered_by');
            $table->foreign('reffered_by')->references('id')->on('users');        
			
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_refferal_externals');
    }
}
