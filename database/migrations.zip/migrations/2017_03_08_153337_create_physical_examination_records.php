<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePhysicalExaminationRecords extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_physical_examination_records',function (Blueprint $table){
            $table->uuid('id');
            $table->primary('id');
            $table->string('observation',100)->nullable();
            $table->string('category',100)->nullable();
            $table->string('system',100)->nullable();
            $table->string('local_examination')->nullable();
            $table->string('gen_examination')->nullable();
            $table->string('summary_examination')->nullable();
            $table->uuid('physical_examination_id');
            $table->foreign('physical_examination_id')->references('id')->on('tbl_physical_examinations');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_physical_examination_records');
    }
}
