<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblForPermissionDischarge extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_permits', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
			$table->uuid('corpse_id');
            $table->uuid('facility_id');
            $table->foreign('corpse_id')->references('id')->on('tbl_corpses');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->integer('permission_status',false,true)->length(1);
            $table->string('descriptions',200)->nullable();
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_permits');
    }
}
