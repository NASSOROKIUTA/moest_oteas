<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblInventoryReceivingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_inventory_receivings', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->string('batch',15)->nullable();
            $table->integer('quantity',false,true)->length(11);
            $table->integer('cost_price',false,true)->length(11)->nullable();
            $table->string('description')->nullable();
            $table->string('asset_number')->nullable();
            $table->string('serial_number')->nullable();
            $table->uuid('item_id');
            $table->foreign('item_id')->references('id')->on('tbl_inventory_items');
            $table->string('supplier',200)->nullable();
            $table->integer('control_balance',false,true)->length(11)->nullable();
            $table->integer('order_status',false,true)->length(11)->default(0);
            $table->uuid('order_number');
            $table->foreign('order_number')->references('id')->on('tbl_inventory_orders');
            $table->string('receive_type',200)->default('normal');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_inventory_receivings');
    }
}
