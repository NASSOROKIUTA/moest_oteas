<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblPrescriptions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_prescriptions', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('item_id');
            $table->foreign('item_id')->references('id')->on('tbl_items');
            $table->uuid('patient_id')->nullable();
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->uuid('prescriber_id');
            $table->foreign('prescriber_id')->references('id')->on('users');
			$table->uuid('verifier_id')->nullable();
            $table->foreign('verifier_id')->references('id')->on('users');
            $table->uuid('dispenser_id')->nullable();
            $table->foreign('dispenser_id')->references('id')->on('users');
			$table->uuid('admission_id')->nullable();
            $table->foreign('admission_id')->references('id')->on('tbl_admissions');
			$table->uuid('visit_id')->nullable();
            $table->foreign('visit_id')->references('id')->on('tbl_accounts_numbers');
            $table->integer('quantity')->nullable();
            $table->string('frequency')->nullable();
            $table->string('duration')->nullable();
            $table->string('dose')->nullable();
            $table->string('cancellation_reason')->nullable();
            $table->string('start_date')->nullable();
            $table->string('instruction')->nullable();
            $table->string('out_of_stock',2)->nullable();
            $table->integer('dispensing_status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_prescriptions');
    }
}
