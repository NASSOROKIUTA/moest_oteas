<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblBloodRequests extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_blood_requests',function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->uuid('requested_by');
            $table->foreign('requested_by')->references('id')->on('users');
            $table->uuid('processed_by')->nullable();
            $table->foreign('processed_by')->references('id')->on('users');
            $table->uuid('visit_id');
            $table->foreign('visit_id')->references('id')->on('tbl_accounts_numbers');
            $table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->integer('dept_id',false,true)->length(11)->unsigned()->nullable();
           
            $table->foreign('dept_id')->references('id')->on('tbl_departments');
            $table->string('blood_group',12)->nullable();
            $table->string('request_reason',200)->nullable();
            $table->integer('unit_requested',false,true)->nullable();
            $table->string('priority',12)->nullable();
            $table->integer('status',false,true)->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_blood_requests');
    }
}
