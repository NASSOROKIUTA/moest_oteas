<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblForObservationsCharts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_observation_charts', function (Blueprint $table) {
          $table->uuid('id');
          $table->primary('id');
		  $table->uuid('admission_id');
          $table->foreign('admission_id')->references('id')->on('tbl_admissions');		
          $table->uuid('observation_type_id');
          $table->foreign('observation_type_id')->references('id')->on('tbl_observation_types');
          $table->float('observed_amount',false,true)->length(4);
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_observation_charts');
    }
}
