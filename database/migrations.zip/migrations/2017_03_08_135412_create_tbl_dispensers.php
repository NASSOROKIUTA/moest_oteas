<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblDispensers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_dispensers', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('item_id');
            $table->foreign('item_id')->references('id')->on('tbl_items');
            $table->uuid('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('received_from_id');
            $table->foreign('received_from_id')->references('id')->on('tbl_store_lists');
            $table->uuid('transaction_type_dispensed_id')->nullable();
            $table->foreign('transaction_type_dispensed_id')->references('id')->on('tbl_transaction_types');
            $table->uuid('dispenser_id');
            $table->foreign('dispenser_id')->references('id')->on('tbl_store_lists');
            $table->uuid('patient_id')->nullable();
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->integer('dispensing_status_id',false,true)->length(11)->unsigned()->nullable();
            $table->foreign('dispensing_status_id')->references('id')->on('tbl_store_request_statuses');
            $table->double('quantity_received')->nullable();
            $table->double('quantity_dispensed')->nullable();
            $table->double('request_amount')->nullable();
            $table->string('batch_no')->nullable();
            $table->string('control');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_dispensers');
    }
}
