<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblBillsCategories extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_bills_categories', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->uuid('account_id');
            $table->foreign('account_id')->references('id')->on('tbl_accounts_numbers');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->integer('main_category_id',false,true)->length(11)->unsigned()->nullable();
           
            $table->foreign('main_category_id')->references('id')->on('tbl_payments_categories');
            $table->integer('bill_id',false,true)->length(11)->unsigned();
            $table->foreign('bill_id')->references('id')->on('tbl_pay_cat_sub_categories');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_bills_categories');
    }
}
