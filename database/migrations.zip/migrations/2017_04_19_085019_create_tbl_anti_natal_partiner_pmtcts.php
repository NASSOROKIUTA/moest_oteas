<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblAntiNatalPartinerPmtcts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_anti_natal_partiner_pmtcts', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_anti_natal_registers');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->string('vvu_infection',6);
            $table->string('has_counsel_given',6);
            $table->date('counselling_date')->nullable();
            $table->string('has_taken_vvu_test',6);
            $table->date('date_of_test_taken')->nullable();
            $table->string('vvu_first_test_result',8);
            $table->string('counselling_after_vvu_test',6);
            $table->string('vvu_second_test_result',8);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_anti_natal_partiner_pmtcts');
    }
}
