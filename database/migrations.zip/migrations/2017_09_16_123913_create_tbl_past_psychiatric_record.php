<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblPastPsychiatricRecord extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_past_psych_records', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
			$table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->uuid('visit_date_id');
            $table->foreign('visit_date_id')->references('id')->on('tbl_accounts_numbers');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->string('past_psychiatric_history',250);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_past_psych_records');
    }
}
