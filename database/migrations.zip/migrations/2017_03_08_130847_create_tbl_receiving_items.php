<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblReceivingItems extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_receiving_items', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('item_id');
            $table->foreign('item_id')->references('id')->on('tbl_items');
            $table->uuid('received_store_id')->nullable();
            $table->foreign('received_store_id')->references('id')->on('tbl_store_lists');
            $table->uuid('invoice_refference')->nullable();
            $table->foreign('invoice_refference')->references('id')->on('tbl_invoices');
            $table->uuid('transaction_type_id')->nullable();
            $table->foreign('transaction_type_id')->references('id')->on('tbl_transaction_types');
            $table->uuid('requesting_store_id')->nullable();
            $table->foreign('requesting_store_id')->references('id')->on('tbl_store_lists');
            $table->uuid('internal_issuer_id')->nullable();
            $table->foreign('internal_issuer_id')->references('id')->on('tbl_store_lists');
            $table->integer('order_no')->nullable();
            $table->string('batch_no')->nullable();
            $table->string('remarks')->nullable();
            $table->double('Reorder_level')->nullable();
            $table->double('quantity')->nullable();
            $table->double('requested_amount')->nullable();
            $table->double('issued_quantity')->nullable();
            $table->date('received_date')->nullable();
            $table->date('expiry_date')->nullable();
            $table->double('price')->nullable();
            $table->uuid('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('received_from_id')->nullable();
            $table->foreign('received_from_id')->references('id')->on('tbl_vendors');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->uuid('attachment_id')->nullable();
            $table->foreign('attachment_id')->references('id')->on('tbl_attachments');
            $table->integer('request_status_id',false,true)->length(11)->unsigned()->nullable();
            $table->foreign('request_status_id')->references('id')->on('tbl_store_request_statuses');
            $table->string('control');
            $table->string('control_in')->length(1)->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_receiving_items');
    }
}
