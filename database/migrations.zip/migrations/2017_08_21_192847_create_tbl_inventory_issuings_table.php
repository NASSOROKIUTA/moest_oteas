<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblInventoryIssuingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_inventory_issuings', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->integer('quantity',false,true)->length(11);
            $table->uuid('item_received_id');
            $table->foreign('item_received_id')->references('id')->on('tbl_inventory_receivings');
            $table->uuid('issuing_officer_id');
            $table->foreign('issuing_officer_id')->references('id')->on('users');
            $table->uuid('receiver_id');
            $table->foreign('receiver_id')->references('id')->on('users');
            $table->integer('department_id',false,true)->length(11)->unsigned()->nullable();
           
            $table->foreign('department_id')->references('id')->on('tbl_departments');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_inventory_issuings');
    }
}
