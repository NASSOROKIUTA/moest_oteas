<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblSubStores extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_sub_stores', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('item_id');
            $table->foreign('item_id')->references('id')->on('tbl_items');
            $table->uuid('user_id')->nullable();
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('received_from_id')->nullable();
            $table->foreign('received_from_id')->references('id')->on('tbl_store_lists');
            $table->uuid('issued_store_id')->nullable();
            $table->foreign('issued_store_id')->references('id')->on('tbl_store_lists');
            $table->uuid('requested_store_id')->nullable();
            $table->foreign('requested_store_id')->references('id')->on('tbl_store_lists');
            $table->double('quantity_issued')->nullable();
            $table->double('request_amount')->nullable();
            $table->integer('order_no')->nullable();
            $table->uuid('transaction_type_id')->nullable();
            $table->foreign('transaction_type_id')->references('id')->on('tbl_transaction_types');
            $table->integer('request_status_id',false,true)->length(11)->unsigned()->nullable();
            $table->foreign('request_status_id')->references('id')->on('tbl_store_request_statuses');
            $table->string('batch_no')->nullable();
            $table->double('quantity')->nullable();
            $table->string('control');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_sub_stores');
    }
}
