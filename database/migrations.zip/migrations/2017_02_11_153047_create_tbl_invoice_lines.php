<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblInvoiceLines extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_invoice_lines', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('invoice_id');
            $table->foreign('invoice_id')->references('id')->on('tbl_encounter_invoices');
			$table->uuid('corpse_id')->nullable();
            $table->foreign('corpse_id')->references('id')->on('tbl_corpses');
			
            $table->uuid('item_type_id');
            $table->foreign('item_type_id')->references('id')->on('tbl_item_type_mappeds');
            $table->integer('quantity',false,true)->length(4)->unsigned();
            $table->uuid('item_price_id');
            $table->foreign('item_price_id')->references('id')->on('tbl_item_prices');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('patient_id')->nullable();
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->integer('status_id',false,true)->length(11)->unsigned();
            $table->foreign('status_id')->references('id')->on('tbl_payment_statuses');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->double('discount',false,true)->length(11)->unsigned();
            $table->uuid('discount_by');
            $table->foreign('discount_by')->references('id')->on('users');
            $table->integer('payment_filter',false,true)->length(11)->unsigned()->nullable();
            $table->foreign('payment_filter')->references('id')->on('tbl_pay_cat_sub_categories');
            $table->string('gepg_receipt',50)->nullable();
            $table->integer('payment_method_id',false,true)->length(11)->unsigned()->nullable();
            $table->foreign('payment_method_id')->references('id')->on('tbl_payment_methods');








            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_invoice_lines');
    }
}
