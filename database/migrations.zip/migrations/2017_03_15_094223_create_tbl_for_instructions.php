<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblForInstructions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_instructions', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->string('instructions',100)->nullable();
            $table->string('prescriptions',100)->nullable();
			$table->uuid('admission_id');
            $table->foreign('admission_id')->references('id')->on('tbl_admissions');
			$table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->uuid('bed_id')->nullable();
		    $table->foreign('bed_id')->references('id')->on('tbl_beds');		   
		    $table->uuid('ward_id')->nullable();
		    $table->foreign('ward_id')->references('id')->on('tbl_wards');
		   	$table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
			$table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
			
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_instructions');
    }
}
