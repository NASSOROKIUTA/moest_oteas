<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblChildVitaminRegisters extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_child_vitamin_registers', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('patient_id');
            $table->foreign('patient_id')->references('id')->on('tbl_patients');
            $table->uuid('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->uuid('facility_id');
            $table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->uuid('mother_id');
            $table->foreign('mother_id')->references('id')->on('tbl_patients');
            $table->string('vitamin_given',8);
            $table->date('date')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_child_vitamin_registers');
    }
}
