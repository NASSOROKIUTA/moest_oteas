<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblItemSubDepartmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_item_sub_departments', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('sub_dept_id');
            $table->foreign('sub_dept_id')->references('id')->on('tbl_sub_departments');
            $table->uuid('item_id');
            $table->foreign('item_id')->references('id')->on('tbl_items');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_item_sub_departments');
    }
}
