<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TblPatientInformedConsents extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
               
        Schema::create('tbl_informed_consents', function (Blueprint $table) {
             $table->uuid('id');
             $table->primary('id');
             $table->integer('relationshipsID',false,true)->length(11)->unsigned();
             $table->foreign('relationshipsID')->references('id')->on('tbl_relationships');  
             $table->uuid('visit_date_id');
             $table->foreign('visit_date_id')->references('id')->on('tbl_accounts_numbers');                          
             $table->string('relative_name',100)->nullable();   
             $table->string('dateSigned',10)->nullable();                    
             $table->uuid('admission_id');
             $table->foreign('admission_id')->references('id')->on('tbl_admissions');  
             $table->uuid('patient_id');
             $table->foreign('patient_id')->references('id')->on('tbl_patients');        
             $table->uuid('item_id');
             $table->foreign('item_id')->references('id')->on('tbl_items');              
             $table->uuid('user_id');
             $table->foreign('user_id')->references('id')->on('users');
             $table->uuid('facility_id');
             $table->foreign('facility_id')->references('id')->on('tbl_facilities');    
             $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_informed_consents');
    }
}
