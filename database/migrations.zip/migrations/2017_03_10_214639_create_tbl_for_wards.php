<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblForWards extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_wards', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->string('ward_name',50);
            $table->uuid('ward_type_id');
			$table->foreign('ward_type_id')->references('id')->on('tbl_wards_types');   
			$table->uuid('ward_class_id');
			$table->foreign('ward_class_id')->references('id')->on('tbl_items');
            $table->uuid('facility_id');
			$table->foreign('facility_id')->references('id')->on('tbl_facilities');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_wards');
    }
}
