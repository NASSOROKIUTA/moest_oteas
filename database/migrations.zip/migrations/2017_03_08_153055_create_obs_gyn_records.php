<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateObsGynRecords extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_obs_gyn_records',function (Blueprint $table){
            $table->uuid('id');
            $table->primary('id');
            $table->string('menarche')->nullable();
            $table->string('menopause')->nullable();
            $table->string('menstrual_cycles')->nullable();
            $table->string('std')->nullable();
            $table->string('abortions')->nullable();
            $table->string('contraceptives')->nullable();
            $table->string('due_date')->nullable();
            $table->string('lnmp')->nullable();
            $table->string('gravidity')->nullable();
            $table->string('parity')->nullable();
            $table->string('living_children')->nullable();
            $table->string('gestational_age')->nullable();
            $table->string('category')->nullable();
            $table->uuid('obs_gyn_id');
            $table->foreign('obs_gyn_id')->references('id')->on('tbl_obs_gyns');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_obs_gyn_records');
    }
}
