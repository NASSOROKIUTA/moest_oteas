<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblTblClinicAttendance extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_clinic_attendances', function (Blueprint $table) {
            $table->uuid('id');
            $table->primary('id');
            $table->uuid('refferal_id');
            $table->foreign('refferal_id')->references('id')->on('tbl_clinic_instructions');
            $table->uuid('visit_id');
            $table->foreign('visit_id')->references('id')->on('tbl_accounts_numbers');
            $table->date('next_visit')->nullable();
            $table->uuid('follow_up_status')->nullable();
            $table->foreign('follow_up_status')->references('id')->on('tbl_follow_up_statuses');
            $table->uuid('clinic_capacity');
            $table->foreign('clinic_capacity')->references('id')->on('tbl_clinic_capacities');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_clinic_attendances');
    }
}
